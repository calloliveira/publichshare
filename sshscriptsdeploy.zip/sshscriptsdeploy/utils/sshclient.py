from datetime import datetime
from os import path
from .sshserver import SSH

scriptfile = ''
cmdlist = ''

def view_script(scriptpath):
    global scriptfile, cmdlist
    print()
    print('Scripts para deployment:')
    print()
    for i, file in enumerate(scriptpath):
        print(f'[ {i+1} ] - {file}')
    print()
    scriptopt = int(input('Escolha um script para deployment: '))
    while True:
        if scriptopt <= len(scriptpath) and not scriptopt == 0:
            scriptopt -= 1
            break
        else:
            scriptopt = int(input('\033[31mOPÇÃO INVÁLIDA, ESCOLHA A OPÇÃO CORRETA: \033[m'))
    print()
    scriptfile = scriptpath[scriptopt]
    cmdlist = [f'chmod +x /tmp/{scriptfile}', f'/bin/bash /tmp/{scriptfile}', f'rm -rf /tmp/{scriptfile}']


def deploy_sudo(usuario, senha, iplist):
    for i in iplist:
        print()
        print('-------------------- INÍCIO DA EXECUÇÃO --------------------')
        print()
        try:
            client = SSH(i, usuario, senha)
            print(f'IP: {i} - \033[32mConexão SSH efetuada com sucesso!!!\033[m')
        except:
            print(f'\033[31mIP: {i} - Erro ao conectar via SSH!!!\033[m')
            salva_log(i, 'Erro ao conectar via SSH')
        else:
            client.deploy_script(scriptfile)
            print(f'Script: [{scriptfile}] - \033[32mScript copiado com sucesso!!!\033[m')
            for c in cmdlist:
                client.exec_cmd_sudo(senha, c)
                if client.conterror != 0:
                    print(f'[{c}] - \033[31mErro na execução do comando\033[m')
                    salva_log(i, f'[{c}] - Erro na execução do comando')
                    break
                else:
                    print(f'[{c}] - \033[32mComando executado com sucesso\033[m')
            if client.conterror == 0:
                salva_log(i, 'Deploy efetuado com sucesso')
            client.ssh.close()
        print()
        print('-------------------- FIM DA EXECUÇÃO --------------------')


def deploy_root(usuario, senha, iplist):
    for i in iplist:
        print()
        print('-------------------- INÍCIO DA EXECUÇÃO --------------------')
        print()
        try:
            client = SSH(i, usuario, senha)
            print(f'IP: {i} - \033[32mConexão SSH efetuada com sucesso!!!\033[m')
        except:
            print(f'IP: {i} - \033[31mErro ao conectar via SSH!!!\033[m')
            salva_log(i, 'Erro ao conectar via SSH')
        else:
            client.deploy_script(scriptfile)
            print(f'Script: [{scriptfile}] - \033[32mScript copiado com sucesso!!!\033[m')
            for c in cmdlist:
                client.exec_cmd_root(c)
                if client.conterror != 0:
                    print(f'[{c}] - \033[31mErro na execução do comando\033[m')
                    salva_log(i, f'[{c}] - Erro na execução do comando')
                    break
                else:
                    print(f'[{c}] - \033[32mComando executado com sucesso\033[m')
            if client.conterror == 0:
                salva_log(i, 'Deploy efetuado com sucesso')
        print()
        print('-------------------- FIM DA EXECUÇÃO --------------------')


def salva_log(ip, msglog, logtype='exec'):
    data = str(datetime.now())
    hora = data[11:16]
    data = data[0:11]
    logfullpath = (f'log/{data}_log-{logtype}.csv')
    if not path.exists(f'{logfullpath}'):
        logfile = open(f'{logfullpath}', 'w')
        logfile.write('Horario;IP;Status')
    else:
        logfile = open(f'{logfullpath}', 'a')
    logfile.write(f'\n{hora};{ip};{msglog}')
    logfile.close()

