from paramiko import SSHClient, AutoAddPolicy


class SSH:
    
    conterror = 0

    def __init__(self, ip, usuario, pwd):
        self.ssh = SSHClient()
        self.ssh.load_system_host_keys()
        self.ssh.set_missing_host_key_policy(AutoAddPolicy())
        self.ssh.connect(hostname=ip, username=usuario,password=pwd, timeout=2)


    def deploy_script(self, scriptfile):
        ftp_client = self.ssh.open_sftp()
        ftp_client.put(localpath=f'scripts/{scriptfile}', remotepath=f'/tmp/{scriptfile}')


    def exec_cmd_sudo(self, pwd, cmd):
        stdin, stdout, stderr = self.ssh.exec_command('sudo ' + cmd, get_pty=True)
        stdin.write(pwd + '\n')
        stdin.flush()
        if stderr.channel.recv_exit_status() != 0:
            self.conterror += 1


    def exec_cmd_root(self, cmd):
        stdin, stdout, stderr = self.ssh.exec_command(cmd)
        if stderr.channel.recv_exit_status() != 0:
            self.conterror += 1

