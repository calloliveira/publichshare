#!/bin/bash
# -------------------------------------------------------------------------
# @Programa 
# 	@nome: fusioninstall-agent.sh
#	@versao: 1.0
#	@Data 13 de julho de 2022
#   @Local: Raia Drogasil SA - Farmácias    
#	@Autor: Carlos R. de Oliveira - Gestao de ativos / Servicos de TI
# --------------------------------------------------------------------------

uversion=$(lsb_release -sr | sed -ne 's/[^1-2]*\(\([0-8]\.\)\{0,4\}[0-9][^.]\).*/\1/p')

######## Funcoes ########
function Altera_Repo(){
mv /etc/apt/sources.list /etc/apt/sources.list-defaultbkp
wget -c http://asset.rd.com.br/fusion/linux/sources.list-ubuntu$uversion -O /etc/apt/sources.list
}

function Instala_Depencencias(){
apt update
apt install -y dmidecode hwdata ucf hdparm perl libuniversal-require-perl libwww-perl libparse-edid-perl libproc-daemon-perl libfile-which-perl libhttp-daemon-perl libxml-treepp-perl libyaml-perl libnet-cups-perl libnet-ip-perl libdigest-sha-perl libsocket-getaddrinfo-perl libtext-template-perl libxml-xpath-perl libyaml-tiny-perl libnet-snmp-perl libcrypt-des-perl libnet-nbname-perl libdigest-hmac-perl libfile-copy-recursive-perl libparallel-forkmanager-perl libnet-write-perl
}

function Instala_Modulos(){
mkdir /tmp/fusioninventory-agent
cd /tmp/fusioninventory-agent
wget -O- http://asset.rd.com.br/fusion/linux/fusioninventory-components.tar.gz | tar -vx -C /tmp/fusioninventory-agent/
dpkg -i *.deb
}

function Configura_Agente(){
sed -i -e 's/#server = http:\/\/server.domain.com\/glpi\/plugins\/fusioninventory\//server = http:\/\/itservices.rd.com.br\/glpi\/plugins\/fusioninventory\//g' /etc/fusioninventory/agent.cfg
systemctl restart fusioninventory-agent
sleep 2
}

function Limpa_Residuos(){
cd /tmp/
rm -rf /tmp/fusioninventory-agent
rm -rf /etc/apt/source.list
mv /etc/apt/sources.list-defaultbkp /etc/apt/sources.list
pkill -USR1 -f -P 1 fusioninventory-agent
sleep 5
apt update
}

######## Executa Funcoes ########

Altera_Repo
Instala_Depencencias
Instala_Modulos
Configura_Agente
Limpa_Residuos


exit