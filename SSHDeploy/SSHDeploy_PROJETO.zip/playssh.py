from pwinput import pwinput
import csv
from structure import SSH
from os import listdir, system
from platform import system as so

scriptpath = listdir('scripts/') 
senha = cont ='null'
senha2 = 'llun'
iplist = []

######################### CORREÇÃO CORES MSDOS-WINDOWS ##############################

if so() == 'Windows':
    system('reg add HKEY_CURRENT_USER\Console /v VirtualTerminalLevel /t REG_DWORD /d 0x00000001 /f>nul 2>&1')

#####################################################################################

############################## INFORMAÇÕES ##########################################

print('\033[32m')
print('Programa  :   SSHDeploy')
print('Autor     :   Carlos R. de Oliveira')
print('GitHub    :   calloliveira')
print('LinkedIn  :   carlos-oliveira-it')
print('\n')
print(' ####################### FERRAMENTA DE DEPLOY SSH ##############################')
print(' #                                                                             #')
print(' #   1 - Certifique-se de ter copiado o script de instalação que deseja fazer  #')
print(' #   o deploy; (scripts/)                                                      #')
print(' #                                                                             #')
print(' #   2 - Certifique-se de ter preenchido a base de IPs dos terminais a serem   #')
print(' #   alcançados pelo deploy (database/ipdbhosts.csv).                          #')
print(' #                                                                             #')
print(' ###############################################################################')
print('\033[m')

#######################################################################################

############################## LEITURA DO BANCO DE IPs ################################

with open('database/iphostsdb.csv', 'r', encoding='utf-8') as ipdbhosts:
    csvips = csv.reader(ipdbhosts, delimiter=';')
    if csvips:
        for i in csvips:
            iplist.append(i[0])
    ipdbhosts.close()

#######################################################################################

##################### VERIFICAR BANCO DE IPS E PATH SCRIPTS ###########################

while True:
    if len(scriptpath) == 0:
        print('\033[31mA pasta de scripts está vazia!!!')
        input('Feche o programa, copie o script para o diretório e abra novamente!!!')
        print('\033[m')
    else:
        if len(iplist) == 0:
            print('\033[31mO Banco de IPs está vazio!!!')
            input('Feche o programa, cadastre os IPs e abra novamente!!!')
            print('\033[m')
        else:
            break

#######################################################################################

################################# CONEXÃO SSH #########################################

print('Scripts para deployment:')
print()
for i, file in enumerate(scriptpath):
    print(f'[ {i+1} ] - {file}')
print()

scriptopt = int(input('Escolha um script para deployment: '))

while True:
    if scriptopt <= len(scriptpath) and not scriptopt == 0:
        scriptopt -= 1
        break
    else:
        scriptopt = int(input('\033[31mOPÇÃO INVÁLIDA, ESCOLHA A OPÇÃO CORRETA: \033[m'))
print()

scriptfile = scriptpath[scriptopt]

cmdlist = [f'chmod +x /tmp/{scriptfile}', f'/bin/bash /tmp/{scriptfile}', f'rm -rf /tmp/{scriptfile}']

def conecta_sudo(usuario, senha):
    for i in iplist:
        print()
        print('-------------------- INÍCIO DA EXECUÇÃO --------------------')
        print()
        try:
            client = SSH(i, usuario, senha, scriptfile)
            for c in cmdlist:
                client.exec_cmd_sudo(senha, c)
            if client.conterror != 0:
                SSH.salva_log(i, 'Erro na execução dos comandos')
            else:
                SSH.salva_log(i, 'Comandos executados com sucesso')
        except:
            SSH.salva_log(i, 'Erro na conexão SSH')
            print(f'\033[31mErro ao conectar no IP: {i}, via SSH!!!\033[m')
        print()
        print('-------------------- FIM DA EXECUÇÃO --------------------')


def conecta_root(usuario, senha):
    for i in iplist:
        print()
        print('-------------------- INÍCIO DA EXECUÇÃO --------------------')
        print()
        try:
            client = SSH(i, usuario, senha, scriptfile)
            for c in cmdlist:
                client.exec_cmd_root(senha, c)
            if client.conterror != 0:
                SSH.salva_log(i, 'Erro na execução dos comandos')
            else:
                SSH.salva_log(i, 'Comandos executados com sucesso')
        except:
            SSH.salva_log(i, 'Erro na conexão SSH')
            print(f'\033[31mErro ao conectar no IP: {i}, via SSH!!!\033[m')
        print()
        print('-------------------- FIM DA EXECUÇÃO --------------------')

#######################################################################################

############################ INTERAÇÃO USUÁRIO ########################################

print('=' * 80)
print(f'{"TIPO DE USUARIO":-^80}')
print('=' * 80)
print('1 - Root')
print('2 - Sudo')
print('=' * 80)
print()
while True:
    usertype = int(input('Escolha o tipo de execução: '))
    if usertype == 1:
        usuario = 'root'
        break
    elif usertype == 2:
        usuario = str(input('Digite o usuário: '))
        break
    else:
        print('\033[31mOPÇÃO INVÁLIDA, ESCOLHA A OPÇÃO CORRETA:\033[m')
        print()
while senha != senha2:
    senha = pwinput(prompt=f'Digite a senha para {usuario}: ')
    senha2 = pwinput(prompt=f'Confirme a senha para {usuario}: ')
    if not senha == senha2:
        print()
        print('\033[31mAS SENHAS NÃO CONFEREM, DIGITE NOVAMENTE!!!\033[m')
        print()
while not cont in 'SNsn':
    print()
    cont = str(input(f'Deseja prosseguir com a execução através do usuário {usuario} [S/N]? '))      
    if not cont in 'SsNn':
        print()
        print('\033[31OPÇÃO INVÁLIDA, ESCOLHA A OPÇÃO CORRETA: \033[m')
if cont in 'Ss':
    if usuario == 'root':
        conecta_root(usuario, senha)
    else:
        conecta_sudo(usuario, senha)

print('\033[32m')
print('Deploy SSH finalizado!!!')
print('Obrigado!!!')
print('By Call Oliveira')
print()
input('Pressione qualquer tecla para sair... ')
print('\033[m')

############################################################################